import matplotlib.pyplot as plt
import seaborn as sns

sns.set_theme()
sns.set_palette(sns.color_palette('pastel'))
