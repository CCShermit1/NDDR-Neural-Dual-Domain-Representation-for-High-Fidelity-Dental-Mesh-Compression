struct Payload {
	uint pindex;
	uint resolution;
};
